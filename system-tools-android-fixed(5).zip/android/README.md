# System Tools — Wallpaper Manager

Скрытный переключатель двух наборов обоев: **публичный** и **скрытый**.
Фото, GIF и видео (live wallpaper). Триггеры работают в фоне и переживают перезагрузку.

Пакет: `com.systemtools.wallpaper`  
Минимум: Android 10 (API 29)

## Сборка в Android Studio

1. Установите [Android Studio](https://developer.android.com/studio) Ladybug или новее, SDK 35, JDK 17.
2. `File → Open` → папка `android` из этого архива.
3. Дождитесь Gradle Sync. Если wrapper не подхватился: `File → Settings → Build → Gradle` и «Use Gradle from: ‘gradle-wrapper.properties’».
4. Подключите телефон с USB-отладкой или запустите эмулятор API 29+.
5. `Run ▶ app`.

Из командной строки (если установлен SDK):

```bash
cd android
chmod +x gradlew
./gradlew :app:assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Переменная `ANDROID_HOME` должна указывать на SDK (обычно `~/Android/Sdk`).

## Первый запуск

1. Откройте приложение. Если включена обманка — это калькулятор.
2. Код по умолчанию `2580`.
   - `2580` затем `=` — открыть сейф.
   - `2580` затем `%` — тихо сменить набор обоев.
3. Добавьте обои в два набора (фото / GIF / видео).
4. Нажмите **Сделать live wallpaper** и подтвердите системный диалог один раз.
   После этого смена наборов мгновенная, без диалога.
5. Настройки → Специальные возможности → System Tools — для комбинации громкости.
6. Шторка → редактировать плитки → **Wallpaper**.

## Триггеры

| Способ | Как |
| --- | --- |
| Плитка в шторке | Короткое нажатие переключает набор. Долгое — открывает приложение даже без иконки. |
| Свайп / двойной / тройной тап | Жесты по live wallpaper на рабочем столе. |
| Встряхивание | Акселерометр, фон. |
| Громкость + затем − | Быстрая последовательность, служба спец. возможностей. |
| Долгое нажатие на иконку | Системный shortcut «Switch profile». |
| PIN | Калькулятор: PIN + `%`. |
| Расписание | Ночью скрытый набор, днём публичный. |
| Наушники | Проводные и Bluetooth. |
| Wi-Fi SSID | Подключение к указанной сети. |
| Голос | Фраза, пока открыт сейф. |

## Скрытность

- Нейтральное имя **System Tools**, подмена иконки (Files / Weather / Gallery / Settings).
- Полное скрытие значка лаунчера. Вернуться: долгое нажатие плитки Wallpaper.
- Сейф с `excludeFromRecents` и отдельным `taskAffinity` — в недавних остаётся калькулятор.
- Фоновое уведомление называется **Device care**.

## Разрешения

- `SET_WALLPAPER` — смена обоев
- `FOREGROUND_SERVICE` — датчики и расписание
- `RECEIVE_BOOT_COMPLETED` — восстановление после ребута
- Accessibility / QS tile — системные, из манифеста
- `RECORD_AUDIO` — только голосовая команда
- `NEARBY_WIFI_DEVICES` / location — SSID триггера

## Структура

```
app/src/main/java/com/systemtools/wallpaper/
  WallpaperApp.kt              Application, DataStore, сервис
  data/                        модели, настройки, каталог файлов
  switcher/WallpaperSwitcher.kt единая точка смены набора
  live/LiveWallpaperService.kt  фото, GIF, видео + жесты стола
  triggers/                    плитка, shake, wifi, headset, volume, boot
  stealth/                     activity-alias и shortcut
  ui/                          калькулятор и сейф (Compose)
```
