package com.systemtools.wallpaper.switcher

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import com.systemtools.wallpaper.data.MediaKind
import com.systemtools.wallpaper.data.Profile
import com.systemtools.wallpaper.data.SettingsStore
import com.systemtools.wallpaper.data.WallpaperItem
import com.systemtools.wallpaper.data.WallpaperRepository
import com.systemtools.wallpaper.live.LiveWallpaperService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Единая точка переключения профиля. Live-движок подписан на DataStore
 * и сам меняет кадр — системный диалог «выбрать обои» больше не нужен.
 * Для фото есть запасной путь через WallpaperManager, если live не назначен.
 */
class WallpaperSwitcher(
    private val context: Context,
    private val settings: SettingsStore,
    private val repo: WallpaperRepository,
) {
    suspend fun toggle(reason: String = "") = setProfile(
        if (settings.current().active == Profile.PUBLIC) Profile.PRIVATE else Profile.PUBLIC,
        reason,
    )

    suspend fun setProfile(profile: Profile, @Suppress("UNUSED_PARAMETER") reason: String = "") {
        settings.update { it.copy(active = profile) }
        buzz(profile)
        applyCurrent()
    }

    suspend fun select(id: String) {
        val item = repo.find(id) ?: return
        settings.update {
            if (item.profile == Profile.PUBLIC) it.copy(selectedPublic = id)
            else it.copy(selectedPrivate = id)
        }
        if (settings.current().active == item.profile) applyCurrent()
    }

    suspend fun applyCurrent() = withContext(Dispatchers.IO) {
        val s = settings.current()
        val id = if (s.active == Profile.PUBLIC) s.selectedPublic else s.selectedPrivate
        val item = repo.find(id) ?: repo.of(s.active).firstOrNull() ?: return@withContext
        // LiveWallpaperService читает settings.flow и рисует сам.
        // Если пользователь ещё не назначил live wallpaper — ставим статичный кадр.
        if (item.kind == MediaKind.STILL && !isLiveOurs()) {
            applyStill(item)
        }
    }

    fun isLiveOurs(): Boolean {
        val info = WallpaperManager.getInstance(context).wallpaperInfo ?: return false
        return info.packageName == context.packageName
    }

    private fun applyStill(item: WallpaperItem) {
        val file = runCatching { File(Uri.parse(item.uri).path ?: return) }.getOrNull() ?: return
        val bmp = decodeSampled(file.absolutePath, 1440, 2560) ?: return
        val wm = WallpaperManager.getInstance(context)
        if (Build.VERSION.SDK_INT >= 24) {
            wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM)
        } else {
            @Suppress("DEPRECATION")
            wm.setBitmap(bmp)
        }
    }

    private fun buzz(profile: Profile) {
        val v = context.getSystemService(Vibrator::class.java) ?: return
        val ms = if (profile == Profile.PRIVATE) 40L else 18L
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    companion object {
        fun openLivePicker(context: Context) {
            val comp = ComponentName(context, LiveWallpaperService::class.java)
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, comp)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(intent) }.onFailure {
                context.startActivity(
                    Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        }

        fun decodeSampled(path: String, reqW: Int, reqH: Int): android.graphics.Bitmap? {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            var sample = 1
            val h = bounds.outHeight
            val w = bounds.outWidth
            if (h > reqH || w > reqW) {
                var halfH = h / 2
                var halfW = w / 2
                while (halfH / sample >= reqH && halfW / sample >= reqW) sample *= 2
            }
            return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    }
}
