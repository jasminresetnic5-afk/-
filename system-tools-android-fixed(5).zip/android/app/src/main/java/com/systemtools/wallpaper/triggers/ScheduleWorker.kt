package com.systemtools.wallpaper.triggers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.systemtools.wallpaper.WallpaperApp
import com.systemtools.wallpaper.data.Profile
import java.util.concurrent.TimeUnit

/**
 * Запасной путь, если система убила foreground-сервис:
 * раз в 15 минут сверяем расписание и поднимаем TriggerService.
 */
class ScheduleWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as? WallpaperApp ?: return Result.retry()
        val s = app.settings.current()
        if (s.schedule) {
            val night = isNight(s.nightStart, s.nightEnd)
            app.switcher.setProfile(if (night) Profile.PRIVATE else Profile.PUBLIC, "schedule")
        }
        TriggerService.start(app)
        app.switcher.applyCurrent()
        return Result.success()
    }

    companion object {
        fun enqueue(context: Context) {
            val req = PeriodicWorkRequestBuilder<ScheduleWorker>(15, TimeUnit.MINUTES)
                .setInitialDelay(15, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "wm-schedule",
                ExistingPeriodicWorkPolicy.UPDATE,
                req,
            )
        }
    }
}
