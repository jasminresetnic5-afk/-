package com.systemtools.wallpaper.triggers

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.systemtools.wallpaper.WallpaperApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Ловит комбинацию громкость+ затем громкость− (без перехвата самих клавиш,
 * громкость продолжает работать). Нужно включить службу в настройках.
 */
class KeyAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var lastKey = 0
    private var lastAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val now = SystemClock.uptimeMillis()
        if (lastKey == KeyEvent.KEYCODE_VOLUME_UP &&
            code == KeyEvent.KEYCODE_VOLUME_DOWN &&
            now - lastAt < 800
        ) {
            lastKey = 0
            scope.launch {
                val app = WallpaperApp.instance
                if (app.settings.current().volumeCombo) app.switcher.toggle("volume")
            }
        } else {
            lastKey = code
            lastAt = now
        }
        return false
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
