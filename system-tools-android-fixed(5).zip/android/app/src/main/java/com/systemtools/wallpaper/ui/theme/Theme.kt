package com.systemtools.wallpaper.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0C0E12)
val SurfaceCol = Color(0xFF15181F)
val Surface2 = Color(0xFF1C2029)
val Fg = Color(0xFFECEEF2)
val Muted = Color(0xFF9AA1AD)
val Accent = Color(0xFFC5CCD6)
val PrivateTone = Color(0xFFC4A484)
val PublicTone = Color(0xFF8FAF9A)
val Danger = Color(0xFFC98980)
val Border = Color(0xFF2A303B)

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Bg,
    background = Bg,
    onBackground = Fg,
    surface = SurfaceCol,
    onSurface = Fg,
    surfaceVariant = Surface2,
    onSurfaceVariant = Muted,
    secondary = PrivateTone,
    onSecondary = Bg,
    error = Danger,
    outline = Border,
)

@Composable
fun SystemToolsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
