package com.systemtools.wallpaper.triggers

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.systemtools.wallpaper.R
import com.systemtools.wallpaper.WallpaperApp
import com.systemtools.wallpaper.data.Profile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Плитка в шторке уведомлений. Короткое нажатие переключает набор. */
class QuickTileService : TileService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onStartListening() {
        scope.launch { paint() }
    }

    override fun onClick() {
        scope.launch {
            val app = application as WallpaperApp
            if (!app.settings.current().tile) return@launch
            app.switcher.toggle("tile")
            paint()
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun paint() {
        val tile = qsTile ?: return
        val app = application as WallpaperApp
        val s = app.settings.current()
        tile.label = getString(R.string.tile_label)
        tile.state = if (s.active == Profile.PRIVATE) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
