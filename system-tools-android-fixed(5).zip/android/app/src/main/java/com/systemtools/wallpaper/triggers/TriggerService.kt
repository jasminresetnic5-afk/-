package com.systemtools.wallpaper.triggers

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.systemtools.wallpaper.R
import com.systemtools.wallpaper.WallpaperApp
import com.systemtools.wallpaper.data.Profile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.math.sqrt

/**
 * Фоновый сервис: встряхивание, наушники, Wi-Fi SSID, ночное расписание.
 * Уведомление маскируется под «Device care».
 *
 * Все обращения к Context / mainLooper — только после onCreate (через lazy
 * или внутри lifecycle-методов), чтобы не ловить NPE в конструкторе.
 */
class TriggerService : Service(), SensorEventListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var sensorManager: SensorManager? = null
    private var lastShake = 0L
    private var lastNight: Boolean? = null
    private var lastSsid: String? = null

    // Context ещё null в <init> — только lazy / onCreate
    private val ticker by lazy { Handler(Looper.getMainLooper()) }

    private val tick = object : Runnable {
        override fun run() {
            scope.launch {
                runCatching { checkSchedule() }
                runCatching { checkWifi() }
            }
            ticker.postDelayed(this, 30_000)
        }
    }

    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            scope.launch { runCatching { checkWifi() } }
        }
        override fun onLost(network: Network) {
            scope.launch { runCatching { checkWifi() } }
        }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            scope.launch { runCatching { checkWifi() } }
        }
    }

    private val audioCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>) {
            if (added.any { it.isSink && it.isHeadset() }) {
                scope.launch {
                    runCatching {
                        val s = WallpaperApp.instance.settings.current()
                        if (s.headphones) {
                            WallpaperApp.instance.switcher.setProfile(Profile.PRIVATE, "headset")
                        }
                    }
                }
            }
        }
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>) {
            if (removed.any { it.isSink && it.isHeadset() }) {
                scope.launch {
                    runCatching {
                        val s = WallpaperApp.instance.settings.current()
                        if (s.headphones) {
                            WallpaperApp.instance.switcher.setProfile(Profile.PUBLIC, "headset-off")
                        }
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        runCatching { createChannel() }
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle(getString(R.string.care_title))
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, n)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "startForeground failed", t)
            // Без foreground система убьёт сервис — всё равно выходим аккуратно
            stopSelf()
            return
        }

        runCatching {
            sensorManager = getSystemService(SensorManager::class.java)
            sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
        runCatching {
            getSystemService(ConnectivityManager::class.java)
                ?.registerDefaultNetworkCallback(netCb)
        }
        runCatching {
            getSystemService(AudioManager::class.java)
                ?.registerAudioDeviceCallback(audioCb, ticker)
        }
        ticker.post(tick)
    }

    override fun onDestroy() {
        runCatching { ticker.removeCallbacks(tick) }
        runCatching { sensorManager?.unregisterListener(this) }
        runCatching {
            getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(netCb)
        }
        runCatching {
            getSystemService(AudioManager::class.java)?.unregisterAudioDeviceCallback(audioCb)
        }
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onSensorChanged(event: SensorEvent) {
        val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
        val g = sqrt((x * x + y * y + z * z).toDouble()) / SensorManager.GRAVITY_EARTH
        if (g < 2.4) return
        val now = System.currentTimeMillis()
        if (now - lastShake < 1200) return
        lastShake = now
        scope.launch {
            runCatching {
                val app = WallpaperApp.instance
                if (app.settings.current().shake) app.switcher.toggle("shake")
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private suspend fun checkSchedule() {
        val s = WallpaperApp.instance.settings.current()
        if (!s.schedule) return
        val night = isNight(s.nightStart, s.nightEnd)
        if (lastNight == null) {
            lastNight = night
            return
        }
        if (night == lastNight) return
        lastNight = night
        WallpaperApp.instance.switcher.setProfile(
            if (night) Profile.PRIVATE else Profile.PUBLIC,
            "schedule",
        )
    }

    private suspend fun checkWifi() {
        val s = WallpaperApp.instance.settings.current()
        if (!s.wifi || s.wifiSsid.isBlank()) return
        val ssid = currentSsid()?.trim('"') ?: run {
            if (lastSsid != null && lastSsid.equals(s.wifiSsid.trim(), true)) {
                lastSsid = null
                WallpaperApp.instance.switcher.setProfile(Profile.PUBLIC, "wifi-off")
            }
            return
        }
        if (ssid == lastSsid || ssid == "<unknown ssid>") return
        val prev = lastSsid
        lastSsid = ssid
        val target = s.wifiSsid.trim()
        if (ssid.equals(target, true)) {
            WallpaperApp.instance.switcher.setProfile(Profile.PRIVATE, "wifi")
        } else if (prev.equals(target, true)) {
            WallpaperApp.instance.switcher.setProfile(Profile.PUBLIC, "wifi-off")
        }
    }

    private fun currentSsid(): String? {
        val wm = getSystemService(WifiManager::class.java) ?: return null
        @Suppress("DEPRECATION")
        return wm.connectionInfo?.ssid
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.care_channel), NotificationManager.IMPORTANCE_MIN),
        )
    }

    companion object {
        private const val CHANNEL = "care"
        private const val TAG = "TriggerService"

        fun start(ctx: Context) {
            runCatching {
                val i = Intent(ctx, TriggerService::class.java)
                if (Build.VERSION.SDK_INT >= 26) {
                    ctx.startForegroundService(i)
                } else {
                    ctx.startService(i)
                }
            }.onFailure { Log.e(TAG, "start failed", it) }
        }
    }
}

private fun AudioDeviceInfo.isHeadset(): Boolean = type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
    type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
    type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
    type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
    type == AudioDeviceInfo.TYPE_USB_HEADSET

fun isNight(start: String, end: String, cal: Calendar = Calendar.getInstance()): Boolean {
    fun min(s: String): Int {
        val p = s.split(":")
        return p.getOrNull(0)?.toIntOrNull()?.times(60)?.plus(p.getOrNull(1)?.toIntOrNull() ?: 0) ?: 0
    }
    val t = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    val a = min(start); val b = min(end)
    if (a == b) return false
    return if (a < b) t in a until b else t >= a || t < b
}
