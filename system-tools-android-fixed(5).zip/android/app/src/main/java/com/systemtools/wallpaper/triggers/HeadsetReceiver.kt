package com.systemtools.wallpaper.triggers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import com.systemtools.wallpaper.WallpaperApp
import com.systemtools.wallpaper.data.Profile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HeadsetReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = WallpaperApp.instance
        CoroutineScope(Dispatchers.Main).launch {
            val s = app.settings.current()
            if (!s.headphones) return@launch
            when (intent.action) {
                Intent.ACTION_HEADSET_PLUG -> {
                    val state = intent.getIntExtra("state", 0)
                    app.switcher.setProfile(if (state == 1) Profile.PRIVATE else Profile.PUBLIC, "headset")
                }
                AudioManager.ACTION_AUDIO_BECOMING_NOISY -> {
                    app.switcher.setProfile(Profile.PUBLIC, "headset-off")
                }
            }
        }
    }
}
