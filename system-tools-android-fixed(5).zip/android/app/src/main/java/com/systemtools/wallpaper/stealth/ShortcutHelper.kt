package com.systemtools.wallpaper.stealth

import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import com.systemtools.wallpaper.R
import com.systemtools.wallpaper.data.AppSettings
import com.systemtools.wallpaper.ui.CalculatorActivity

/** Долгое нажатие на иконку лаунчера → системное меню со shortcut «Switch profile». */
object ShortcutHelper {
    const val ACTION_SWITCH = "com.systemtools.wallpaper.SWITCH"

    fun apply(context: Context, settings: AppSettings) {
        val sm = context.getSystemService(ShortcutManager::class.java) ?: return
        if (!settings.longPress) {
            sm.removeAllDynamicShortcuts()
            runCatching { sm.disableShortcuts(listOf("switch_profile")) }
            return
        }
        runCatching { sm.enableShortcuts(listOf("switch_profile")) }
        val shortcut = ShortcutInfo.Builder(context, "switch_profile")
            .setShortLabel(context.getString(R.string.shortcut_switch))
            .setIcon(Icon.createWithResource(context, R.drawable.ic_tile))
            .setIntent(
                Intent(context, CalculatorActivity::class.java)
                    .setAction(ACTION_SWITCH),
            )
            .build()
        sm.setDynamicShortcuts(listOf(shortcut))
    }
}
