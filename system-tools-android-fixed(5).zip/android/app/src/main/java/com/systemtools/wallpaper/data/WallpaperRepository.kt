package com.systemtools.wallpaper.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.URI
import java.util.UUID

/**
 * Каталог обоев в filesDir. URI копируются внутрь приложения,
 * чтобы пережить отзыв grant и перезагрузку.
 */
class WallpaperRepository(private val context: Context) {
    private val indexFile get() = File(context.filesDir, "wallpapers.json")
    private val mediaDir get() = File(context.filesDir, "media").apply { mkdirs() }

    private val _items = MutableStateFlow(readIndex())
    val items: StateFlow<List<WallpaperItem>> = _items.asStateFlow()

    fun all(): List<WallpaperItem> = _items.value

    fun add(profile: Profile, kind: MediaKind, title: String, source: InputStream, ext: String): WallpaperItem {
        val id = UUID.randomUUID().toString()
        val safeExt = ext.lowercase().filter { it.isLetterOrDigit() }.ifBlank { "bin" }
        val dest = File(mediaDir, "$id.$safeExt")
        source.use { input -> dest.outputStream().use { input.copyTo(it) } }
        val item = WallpaperItem(id, profile, kind, title.ifBlank { "Wallpaper" }, dest.toURI().toString())
        persist(all() + item)
        return item
    }

    fun remove(id: String) {
        val doomed = all().find { it.id == id }
        persist(all().filterNot { it.id == id })
        doomed?.let { runCatching { File(URI(it.uri)).delete() } }
    }

    fun of(profile: Profile) = all().filter { it.profile == profile }

    fun find(id: String?) = all().find { it.id == id }

    private fun persist(items: List<WallpaperItem>) {
        val arr = JSONArray()
        items.forEach { w ->
            arr.put(
                JSONObject()
                    .put("id", w.id)
                    .put("profile", w.profile.name)
                    .put("kind", w.kind.name)
                    .put("title", w.title)
                    .put("uri", w.uri),
            )
        }
        indexFile.writeText(arr.toString())
        _items.value = items
    }

    private fun readIndex(): List<WallpaperItem> {
        if (!indexFile.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(indexFile.readText())
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        WallpaperItem(
                            id = o.getString("id"),
                            profile = Profile.valueOf(o.getString("profile")),
                            kind = MediaKind.valueOf(o.getString("kind")),
                            title = o.getString("title"),
                            uri = o.getString("uri"),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList())
    }
}
