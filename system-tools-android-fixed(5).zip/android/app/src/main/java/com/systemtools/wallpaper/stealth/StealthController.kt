package com.systemtools.wallpaper.stealth

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import com.systemtools.wallpaper.data.AppSettings
import com.systemtools.wallpaper.ui.CalculatorActivity

/**
 * Подмена иконки через activity-alias и полное скрытие значка лаунчера.
 * Сама CalculatorActivity всегда включена — вход остаётся через
 * долгое нажатие плитки в шторке (QS_TILE_PREFERENCES).
 */
object StealthController {
    private val aliases = listOf(
        ".alias.Tools" to "tools",
        ".alias.Files" to "files",
        ".alias.Weather" to "weather",
        ".alias.Gallery" to "gallery",
        ".alias.Settings" to "settings",
    )

    fun apply(context: Context, settings: AppSettings) {
        val pm = context.packageManager
        val pkg = context.packageName
        aliases.forEach { (cls, id) ->
            val enabled = !settings.hideIcon && settings.alias == id
            pm.setComponentEnabledSetting(
                ComponentName(pkg, pkg + cls),
                if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
        pm.setComponentEnabledSetting(
            ComponentName(context, CalculatorActivity::class.java),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP,
        )
    }
}
