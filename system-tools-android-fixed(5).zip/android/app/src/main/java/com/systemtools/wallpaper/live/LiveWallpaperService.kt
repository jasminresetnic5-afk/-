package com.systemtools.wallpaper.live

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Rect
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import com.systemtools.wallpaper.WallpaperApp
import com.systemtools.wallpaper.data.MediaKind
import com.systemtools.wallpaper.data.Profile
import com.systemtools.wallpaper.data.WallpaperItem
import com.systemtools.wallpaper.switcher.WallpaperSwitcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs
import kotlin.math.max

/**
 * Один engine на оба набора. Смена профиля = смена файла, без системного диалога.
 * Жесты рабочего стола ловим здесь (setTouchEventsEnabled).
 *
 * Важно: для видео не вызываем lockCanvas — Surface принадлежит MediaPlayer.
 */
class LiveWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = EngineImpl()

    inner class EngineImpl : Engine() {
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        private val handler = Handler(Looper.getMainLooper())
        private var bitmap: Bitmap? = null
        private var animated: AnimatedImageDrawable? = null
        private var player: MediaPlayer? = null
        private var item: WallpaperItem? = null
        private var taps = 0
        private var lastTap = 0L
        private var downX = 0f
        private var job: Job? = null

        private val draw = object : Runnable {
            override fun run() {
                if (player != null) return
                drawFrame()
                handler.postDelayed(this, if (animated != null) 32L else 400L)
            }
        }

        private val drawableCallback = object : Drawable.Callback {
            override fun invalidateDrawable(who: Drawable) {
                if (isVisible) drawFrame()
            }
            override fun scheduleDrawable(who: Drawable, what: Runnable, `when`: Long) {
                handler.postAtTime(what, `when`)
            }
            override fun unscheduleDrawable(who: Drawable, what: Runnable) {
                handler.removeCallbacks(what)
            }
        }

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            setTouchEventsEnabled(true)
            job = scope.launch {
                val app = WallpaperApp.instance
                app.settings.flow.collectLatest { s ->
                    val id = if (s.active == Profile.PUBLIC) s.selectedPublic else s.selectedPrivate
                    load(app.repository.find(id) ?: app.repository.of(s.active).firstOrNull())
                }
            }
        }

        override fun onDestroy() {
            handler.removeCallbacks(draw)
            job?.cancel()
            scope.cancel()
            releaseMedia()
            super.onDestroy()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            if (visible) {
                animated?.start()
                player?.takeIf { !it.isPlaying }?.start()
                handler.post(draw)
            } else {
                handler.removeCallbacks(draw)
                animated?.stop()
                runCatching { player?.pause() }
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            player?.setSurface(holder.surface)
            if (player == null) handler.post(draw)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            handler.removeCallbacks(draw)
            super.onSurfaceDestroyed(holder)
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            if (player == null) drawFrame()
        }

        override fun onTouchEvent(event: MotionEvent) {
            val app = WallpaperApp.instance
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> downX = event.x
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    scope.launch {
                        val s = app.settings.current()
                        if (s.swipe && abs(dx) > 80) {
                            app.switcher.toggle("swipe")
                            return@launch
                        }
                        val now = System.currentTimeMillis()
                        taps = if (now - lastTap < 340) taps + 1 else 1
                        lastTap = now
                        val n = taps
                        handler.postDelayed({
                            if (taps != n) return@postDelayed
                            scope.launch {
                                val cur = app.settings.current()
                                if (n >= 3 && cur.tripleTap) app.switcher.toggle("triple")
                                else if (n == 2 && cur.doubleTap) app.switcher.toggle("double")
                            }
                            taps = 0
                        }, 320)
                    }
                }
            }
            super.onTouchEvent(event)
        }

        private fun load(next: WallpaperItem?) {
            if (next?.id == item?.id && next?.uri == item?.uri) {
                if (player == null) drawFrame()
                return
            }
            item = next
            releaseMedia()
            if (next == null) {
                drawFrame()
                return
            }
            val file = runCatching { File(Uri.parse(next.uri).path!!) }.getOrNull()
            if (file == null || !file.exists()) return
            when (next.kind) {
                MediaKind.GIF -> {
                    val drawable = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file))
                    if (drawable is AnimatedImageDrawable) {
                        animated = drawable
                        drawable.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        drawable.callback = drawableCallback
                        drawable.start()
                    } else {
                        bitmap = WallpaperSwitcher.decodeSampled(file.absolutePath, 1440, 2560)
                    }
                }
                MediaKind.LIVE -> {
                    player = MediaPlayer().apply {
                        setDataSource(file.absolutePath)
                        isLooping = true
                        setVolume(0f, 0f)
                        setOnPreparedListener { mp ->
                            surfaceHolder.surface?.let { mp.setSurface(it) }
                            if (isVisible) mp.start()
                        }
                        prepareAsync()
                    }
                }
                MediaKind.STILL -> {
                    bitmap = WallpaperSwitcher.decodeSampled(file.absolutePath, 1440, 2560)
                }
            }
            if (player == null) handler.post(draw)
        }

        private fun releaseMedia() {
            bitmap?.recycle(); bitmap = null
            animated?.stop(); animated?.callback = null; animated = null
            player?.release(); player = null
        }

        private fun drawFrame() {
            if (player != null) return
            val holder = surfaceHolder
            val canvas: Canvas = try {
                holder.lockCanvas() ?: return
            } catch (_: Exception) {
                return
            }
            try {
                canvas.drawColor(Color.BLACK)
                val anim = animated
                val bmp = bitmap
                when {
                    anim != null -> {
                        val scale = max(
                            canvas.width / anim.intrinsicWidth.coerceAtLeast(1).toFloat(),
                            canvas.height / anim.intrinsicHeight.coerceAtLeast(1).toFloat(),
                        )
                        val dw = (anim.intrinsicWidth * scale).toInt()
                        val dh = (anim.intrinsicHeight * scale).toInt()
                        val left = (canvas.width - dw) / 2
                        val top = (canvas.height - dh) / 2
                        anim.setBounds(left, top, left + dw, top + dh)
                        anim.draw(canvas)
                    }
                    bmp != null -> {
                        canvas.drawBitmap(bmp, null, Rect(0, 0, canvas.width, canvas.height), null)
                    }
                }
            } finally {
                runCatching { holder.unlockCanvasAndPost(canvas) }
            }
        }
    }
}
