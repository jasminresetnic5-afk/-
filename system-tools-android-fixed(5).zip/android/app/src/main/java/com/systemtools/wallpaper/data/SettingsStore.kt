package com.systemtools.wallpaper.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("wm_settings")

class SettingsStore(private val context: Context) {
    private object K {
        val ACTIVE = stringPreferencesKey("active")
        val SEL_PUB = stringPreferencesKey("sel_pub")
        val SEL_PRIV = stringPreferencesKey("sel_priv")
        val PIN = stringPreferencesKey("pin")
        val PIN_ON = booleanPreferencesKey("pin_on")
        val HIDE = booleanPreferencesKey("hide")
        val DECOY = booleanPreferencesKey("decoy")
        val ALIAS = stringPreferencesKey("alias")
        val NAME = stringPreferencesKey("name")
        val TILE = booleanPreferencesKey("tile")
        val SWIPE = booleanPreferencesKey("swipe")
        val DBL = booleanPreferencesKey("dbl")
        val TRIPLE = booleanPreferencesKey("triple")
        val SHAKE = booleanPreferencesKey("shake")
        val VOL = booleanPreferencesKey("vol")
        val LONG = booleanPreferencesKey("long")
        val SCHED = booleanPreferencesKey("sched")
        val NSTART = stringPreferencesKey("nstart")
        val NEND = stringPreferencesKey("nend")
        val HEAD = booleanPreferencesKey("head")
        val WIFI = booleanPreferencesKey("wifi")
        val SSID = stringPreferencesKey("ssid")
        val VOICE = booleanPreferencesKey("voice")
        val PHRASE = stringPreferencesKey("phrase")
    }

    val flow: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            active = runCatching { Profile.valueOf(p[K.ACTIVE] ?: "PUBLIC") }.getOrDefault(Profile.PUBLIC),
            selectedPublic = p[K.SEL_PUB],
            selectedPrivate = p[K.SEL_PRIV],
            pin = p[K.PIN] ?: "2580",
            pinEnabled = p[K.PIN_ON] ?: true,
            hideIcon = p[K.HIDE] ?: false,
            decoy = p[K.DECOY] ?: true,
            alias = p[K.ALIAS] ?: "tools",
            appName = p[K.NAME] ?: "System Tools",
            tile = p[K.TILE] ?: true,
            swipe = p[K.SWIPE] ?: true,
            doubleTap = p[K.DBL] ?: true,
            tripleTap = p[K.TRIPLE] ?: true,
            shake = p[K.SHAKE] ?: true,
            volumeCombo = p[K.VOL] ?: true,
            longPress = p[K.LONG] ?: true,
            schedule = p[K.SCHED] ?: false,
            nightStart = p[K.NSTART] ?: "22:00",
            nightEnd = p[K.NEND] ?: "07:00",
            headphones = p[K.HEAD] ?: false,
            wifi = p[K.WIFI] ?: false,
            wifiSsid = p[K.SSID] ?: "",
            voice = p[K.VOICE] ?: false,
            voicePhrase = p[K.PHRASE] ?: "переключи обои",
        )
    }

    suspend fun current(): AppSettings = flow.first()

    suspend fun update(block: (AppSettings) -> AppSettings) {
        val next = block(current())
        context.dataStore.edit { p ->
            p[K.ACTIVE] = next.active.name
            next.selectedPublic?.let { p[K.SEL_PUB] = it } ?: p.remove(K.SEL_PUB)
            next.selectedPrivate?.let { p[K.SEL_PRIV] = it } ?: p.remove(K.SEL_PRIV)
            p[K.PIN] = next.pin
            p[K.PIN_ON] = next.pinEnabled
            p[K.HIDE] = next.hideIcon
            p[K.DECOY] = next.decoy
            p[K.ALIAS] = next.alias
            p[K.NAME] = next.appName
            p[K.TILE] = next.tile
            p[K.SWIPE] = next.swipe
            p[K.DBL] = next.doubleTap
            p[K.TRIPLE] = next.tripleTap
            p[K.SHAKE] = next.shake
            p[K.VOL] = next.volumeCombo
            p[K.LONG] = next.longPress
            p[K.SCHED] = next.schedule
            p[K.NSTART] = next.nightStart
            p[K.NEND] = next.nightEnd
            p[K.HEAD] = next.headphones
            p[K.WIFI] = next.wifi
            p[K.SSID] = next.wifiSsid
            p[K.VOICE] = next.voice
            p[K.PHRASE] = next.voicePhrase
        }
    }
}
