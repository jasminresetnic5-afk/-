package com.systemtools.wallpaper.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.systemtools.wallpaper.WallpaperApp
import com.systemtools.wallpaper.data.AppSettings
import com.systemtools.wallpaper.data.Profile
import com.systemtools.wallpaper.switcher.WallpaperSwitcher
import com.systemtools.wallpaper.ui.theme.Accent
import com.systemtools.wallpaper.ui.theme.Bg
import com.systemtools.wallpaper.ui.theme.Fg
import com.systemtools.wallpaper.ui.theme.Muted
import com.systemtools.wallpaper.ui.theme.PrivateTone
import com.systemtools.wallpaper.ui.theme.PublicTone
import com.systemtools.wallpaper.ui.theme.Surface2
import com.systemtools.wallpaper.ui.theme.SystemToolsTheme
import kotlinx.coroutines.launch

class VaultActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SystemToolsTheme { VaultScreen() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VaultScreen() {
    val app = WallpaperApp.instance
    val settings by app.settings.flow.collectAsState(initial = AppSettings())
    val items by app.repository.items.collectAsState()
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Обои", "Триггеры", "Скрытность")
    val privateOn = settings.active == Profile.PRIVATE

    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(settings.appName, color = Fg, fontSize = 16.sp)
                        Text("Wallpaper Manager", color = Muted, fontSize = 12.sp)
                    }
                },
                actions = {
                    Text(
                        if (privateOn) "Скрытый" else "Публичный",
                        color = Bg,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .padding(end = 16.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (privateOn) PrivateTone else PublicTone)
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 16.dp),
        ) {
            Button(
                onClick = { scope.launch { app.switcher.toggle("button") } },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
            ) { Text("Переключить набор") }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { WallpaperSwitcher.openLivePicker(app) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Surface2, contentColor = Fg),
            ) { Text(if (app.switcher.isLiveOurs()) "Live wallpaper назначен" else "Сделать live wallpaper") }
            Spacer(Modifier.height(12.dp))
            TabRow(
                selectedTabIndex = tab,
                containerColor = Surface2,
                contentColor = Fg,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                indicator = { pos ->
                    if (tab < pos.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(pos[tab]),
                            color = Accent,
                        )
                    }
                },
            ) {
                tabs.forEachIndexed { i, label ->
                    Tab(
                        selected = tab == i,
                        onClick = { tab = i },
                        text = { Text(label, fontSize = 13.sp) },
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            when (tab) {
                0 -> GalleryPane(settings, items)
                1 -> TriggersPane(settings)
                else -> StealthPane(settings)
            }
        }
    }
}

@Composable
internal fun SectionLabel(text: String) {
    Text(text, color = Muted, fontSize = 12.sp, style = MaterialTheme.typography.labelMedium)
}
