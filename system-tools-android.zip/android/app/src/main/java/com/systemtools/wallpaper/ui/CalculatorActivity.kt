package com.systemtools.wallpaper.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.systemtools.wallpaper.WallpaperApp
import com.systemtools.wallpaper.stealth.ShortcutHelper
import com.systemtools.wallpaper.ui.theme.Accent
import com.systemtools.wallpaper.ui.theme.Bg
import com.systemtools.wallpaper.ui.theme.Fg
import com.systemtools.wallpaper.ui.theme.Muted
import com.systemtools.wallpaper.ui.theme.Surface2
import com.systemtools.wallpaper.ui.theme.SystemToolsTheme
import kotlinx.coroutines.launch

/**
 * Видимая точка входа. Если включена обманка — обычный калькулятор.
 * PIN + «=» открывает сейф. PIN + «%» тихо переключает набор обоев.
 * Shortcut с иконки (ACTION_SWITCH) переключает набор и закрывается.
 */
class CalculatorActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent.action == ShortcutHelper.ACTION_SWITCH) {
            handleSwitchIntent(intent)
            return
        }
        requestStartupPermissions()
        lifecycleScope.launch {
            val s = WallpaperApp.instance.settings.current()
            if (!s.decoy) {
                startActivity(Intent(this@CalculatorActivity, VaultActivity::class.java))
                finish()
                return@launch
            }
            setContent {
                SystemToolsTheme {
                    CalculatorScreen(onUnlock = {
                        startActivity(Intent(this@CalculatorActivity, VaultActivity::class.java))
                    })
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleSwitchIntent(intent)
    }

    private fun handleSwitchIntent(intent: Intent?) {
        if (intent?.action != ShortcutHelper.ACTION_SWITCH) return
        lifecycleScope.launch {
            val app = WallpaperApp.instance
            if (app.settings.current().longPress) app.switcher.toggle("icon")
            finish()
        }
    }

    private fun requestStartupPermissions() {
        val needed = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
            else add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        permissionLauncher.launch(needed.toTypedArray())
    }
}

@Composable
private fun CalculatorScreen(onUnlock: () -> Unit) {
    val app = WallpaperApp.instance
    val scope = rememberCoroutineScope()
    var display by remember { mutableStateOf("0") }
    var acc by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<String?>(null) }
    var fresh by remember { mutableStateOf(true) }

    fun apply(key: String) {
        scope.launch {
            val s = app.settings.current()
            if (key == "=" && s.pinEnabled && display == s.pin) {
                onUnlock()
                return@launch
            }
            if (key == "%" && s.pinEnabled && display == s.pin) {
                app.switcher.toggle("pin")
                display = runCatching { (s.pin.toDouble() / 100.0).toString() }.getOrDefault("0")
                fresh = true
                return@launch
            }
            when (key) {
                "C" -> {
                    display = "0"; acc = null; op = null; fresh = true
                }
                "±" -> display = if (display.startsWith("-")) display.drop(1) else if (display == "0") display else "-$display"
                "%" -> {
                    display = (display.toDoubleOrNull()?.div(100) ?: 0.0).toString()
                    fresh = true
                }
                "+", "−", "×", "÷" -> {
                    acc = display.toDoubleOrNull(); op = key; fresh = true
                }
                "=" -> {
                    val a = acc ?: return@launch
                    val b = display.toDoubleOrNull() ?: return@launch
                    val r = when (op) {
                        "+" -> a + b
                        "−" -> a - b
                        "×" -> a * b
                        "÷" -> if (b == 0.0) Double.NaN else a / b
                        else -> b
                    }
                    display = if (r.isFinite()) r.toString().trimEnd('0').trimEnd('.') else "Error"
                    acc = null; op = null; fresh = true
                }
                "." -> {
                    display = if (fresh) "0." else if (display.contains(".")) display else "$display."
                    fresh = false
                }
                else -> {
                    display = if (fresh || display == "0") key else (display + key).take(12)
                    fresh = false
                }
            }
        }
    }

    val keys = listOf(
        listOf("C", "±", "%", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "−"),
        listOf("1", "2", "3", "+"),
        listOf("0", ".", "="),
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(20.dp),
    ) {
        Text("CALCULATOR", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 2.sp)
        Text(
            display,
            color = Fg,
            fontSize = 48.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 48.dp, bottom = 24.dp),
        )
        keys.forEach { row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                row.forEach { key ->
                    val opKey = key in listOf("÷", "×", "−", "+", "=")
                    TextButton(
                        onClick = { apply(key) },
                        modifier = Modifier
                            .weight(if (key == "0") 2f else 1f)
                            .height(64.dp)
                            .background(if (opKey) Accent else Surface2, RoundedCornerShape(8.dp)),
                    ) {
                        Text(key, color = if (opKey) Bg else Fg, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}
