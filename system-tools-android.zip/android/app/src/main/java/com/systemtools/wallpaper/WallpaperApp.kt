package com.systemtools.wallpaper

import android.app.Application
import com.systemtools.wallpaper.data.SettingsStore
import com.systemtools.wallpaper.data.WallpaperRepository
import com.systemtools.wallpaper.stealth.ShortcutHelper
import com.systemtools.wallpaper.stealth.StealthController
import com.systemtools.wallpaper.switcher.WallpaperSwitcher
import com.systemtools.wallpaper.triggers.ScheduleWorker
import com.systemtools.wallpaper.triggers.TriggerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class WallpaperApp : Application() {
    lateinit var settings: SettingsStore
        private set
    lateinit var repository: WallpaperRepository
        private set
    lateinit var switcher: WallpaperSwitcher
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        instance = this
        settings = SettingsStore(this)
        repository = WallpaperRepository(this)
        switcher = WallpaperSwitcher(this, settings, repository)
        // Восстанавливаем фоновые триггеры после убийства процесса.
        TriggerService.start(this)
        ScheduleWorker.enqueue(this)
        scope.launch {
            settings.flow.collect { s ->
                StealthController.apply(this@WallpaperApp, s)
                ShortcutHelper.apply(this@WallpaperApp, s)
            }
        }
    }

    companion object {
        lateinit var instance: WallpaperApp
            private set
    }
}
