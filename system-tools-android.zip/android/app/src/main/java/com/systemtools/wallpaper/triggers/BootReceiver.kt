package com.systemtools.wallpaper.triggers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.systemtools.wallpaper.WallpaperApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** После ребута поднимаем сервис и заново ставим текущий набор. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        TriggerService.start(context)
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { WallpaperApp.instance.switcher.applyCurrent() }
            pending.finish()
        }
    }
}
