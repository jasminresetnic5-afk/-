package com.systemtools.wallpaper.data

/** Публичный набор — «безопасные» обои. Скрытый — второй профиль. */
enum class Profile { PUBLIC, PRIVATE }

enum class MediaKind { STILL, GIF, LIVE }

data class WallpaperItem(
    val id: String,
    val profile: Profile,
    val kind: MediaKind,
    val title: String,
    /** content:// или file:// URI, который мы сохранили в app files. */
    val uri: String,
)

data class AppSettings(
    val active: Profile = Profile.PUBLIC,
    val selectedPublic: String? = null,
    val selectedPrivate: String? = null,
    val pin: String = "2580",
    val pinEnabled: Boolean = true,
    val hideIcon: Boolean = false,
    val decoy: Boolean = true,
    val firstLaunch: Boolean = true,
    val alias: String = "tools",
    val appName: String = "System Tools",
    val tile: Boolean = true,
    val swipe: Boolean = true,
    val doubleTap: Boolean = true,
    val tripleTap: Boolean = true,
    val shake: Boolean = true,
    val volumeCombo: Boolean = true,
    val longPress: Boolean = true,
    val schedule: Boolean = false,
    val nightStart: String = "22:00",
    val nightEnd: String = "07:00",
    val headphones: Boolean = false,
    val wifi: Boolean = false,
    val wifiSsid: String = "",
    val voice: Boolean = false,
    val voicePhrase: String = "переключи обои",
    val wallpaperScale: Float = 1.0f,
    val wallpaperOffsetX: Float = 0f,
    val wallpaperOffsetY: Float = 0f,
)
