package com.systemtools.wallpaper.ui

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.decode.GifDecoder
import coil.request.ImageRequest
import com.systemtools.wallpaper.WallpaperApp
import com.systemtools.wallpaper.data.AppSettings
import com.systemtools.wallpaper.data.MediaKind
import com.systemtools.wallpaper.data.Profile
import com.systemtools.wallpaper.data.WallpaperItem
import com.systemtools.wallpaper.ui.theme.Accent
import com.systemtools.wallpaper.ui.theme.Bg
import com.systemtools.wallpaper.ui.theme.Border
import com.systemtools.wallpaper.ui.theme.Danger
import com.systemtools.wallpaper.ui.theme.Fg
import com.systemtools.wallpaper.ui.theme.Muted
import com.systemtools.wallpaper.ui.theme.PrivateTone
import com.systemtools.wallpaper.ui.theme.PublicTone
import com.systemtools.wallpaper.ui.theme.Surface2
import com.systemtools.wallpaper.ui.theme.SurfaceCol
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

@Composable
fun GalleryPane(settings: AppSettings, items: List<WallpaperItem>) {
    val app = WallpaperApp.instance
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(Profile.PUBLIC) }
    val list = items.filter { it.profile == tab }
    val selected = if (tab == Profile.PUBLIC) settings.selectedPublic else settings.selectedPrivate

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments(),
    ) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch {
            withContext(Dispatchers.IO) {
                uris.forEach { uri ->
                    val mime = ctx.contentResolver.getType(uri) ?: "image/jpeg"
                    val kind = when {
                        mime == "image/gif" -> MediaKind.GIF
                        mime.startsWith("video/") -> MediaKind.LIVE
                        else -> MediaKind.STILL
                    }
                    val name = queryName(ctx, uri).substringBeforeLast('.')
                    val ext = when {
                        mime.contains("png") -> "png"
                        mime.contains("gif") -> "gif"
                        mime.contains("webp") -> "webp"
                        mime.contains("mp4") -> "mp4"
                        mime.contains("webm") -> "webm"
                        else -> "jpg"
                    }
                    ctx.contentResolver.openInputStream(uri)?.let { input ->
                        val item = app.repository.add(tab, kind, name, input, ext)
                        // select() ниже — на Main, после IO
                        kotlinx.coroutines.withContext(Dispatchers.Main) {
                            app.switcher.select(item.id)
                        }
                    }
                }
            }
            Toast.makeText(ctx, "Добавлено в набор", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Surface2)
                .padding(4.dp),
        ) {
            ProfileChip("Публичный", tab == Profile.PUBLIC, PublicTone, Modifier.weight(1f)) { tab = Profile.PUBLIC }
            ProfileChip("Скрытый", tab == Profile.PRIVATE, PrivateTone, Modifier.weight(1f)) { tab = Profile.PRIVATE }
        }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            modifier = Modifier.weight(1f),
        ) {
            items(list, key = { it.id }) { item ->
                val active = selected == item.id
                Column {
                    Box(
                        Modifier
                            .aspectRatio(3f / 4f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, if (active) Accent else Border, RoundedCornerShape(12.dp))
                            .clickable { scope.launch { app.switcher.select(item.id) } },
                    ) {
                        WallpaperThumb(item)
                        Text(
                            kindLabel(item.kind),
                            color = Bg,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(if (item.profile == Profile.PRIVATE) PrivateTone else PublicTone)
                                .padding(horizontal = 8.dp, vertical = 2.dp),
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(item.title, color = Fg, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
                        IconButton(onClick = {
                            app.repository.remove(item.id)
                        }) {
                            Icon(Icons.Outlined.Delete, contentDescription = "Удалить", tint = Danger, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
            item {
                Box(
                    Modifier
                        .aspectRatio(3f / 4f)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, Border, RoundedCornerShape(12.dp))
                        .background(Surface2)
                        .clickable { picker.launch(arrayOf("image/*", "video/*")) },
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.Add, contentDescription = null, tint = Muted)
                        Spacer(Modifier.height(6.dp))
                        Text("Из галереи", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
        Button(
            onClick = { picker.launch(arrayOf("image/*", "video/*")) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Surface2, contentColor = Fg),
        ) {
            Text("Добавить в ${if (tab == Profile.PUBLIC) "публичный" else "скрытый"} набор")
        }
    }
}

@Composable
private fun WallpaperThumb(item: WallpaperItem) {
    val ctx = LocalContext.current
    val file = runCatching { File(Uri.parse(item.uri).path!!) }.getOrNull()
    if (file == null || !file.exists()) {
        Box(Modifier.fillMaxSize().background(Surface2))
        return
    }
    when (item.kind) {
        MediaKind.LIVE -> {
            val frame = remember(item.id) {
                runCatching {
                    MediaMetadataRetriever().use { r ->
                        r.setDataSource(file.absolutePath)
                        r.frameAtTime
                    }
                }.getOrNull()
            }
            if (frame != null) {
                AsyncImage(model = frame, contentDescription = item.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Box(Modifier.fillMaxSize().background(Surface2), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = null, tint = Fg)
                }
            }
        }
        else -> {
            val req = ImageRequest.Builder(ctx).data(file).crossfade(true)
            if (item.kind == MediaKind.GIF) req.decoderFactory(GifDecoder.Factory())
            AsyncImage(
                model = req.build(),
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
fun PhonePreview(settings: AppSettings, items: List<WallpaperItem>) {
    val app = WallpaperApp.instance
    val selectedId = if (settings.active == Profile.PUBLIC) settings.selectedPublic else settings.selectedPrivate
    val item = items.firstOrNull { it.id == selectedId }
        ?: items.firstOrNull { it.profile == settings.active }
        ?: return

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Surface2)
            .border(1.dp, Accent.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
            .padding(12.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp))
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val nextScale = (settings.wallpaperScale * zoom).coerceIn(0.75f, 3f)
                        val nextX = (settings.wallpaperOffsetX + pan.x * 0.9f).coerceIn(-500f, 500f)
                        val nextY = (settings.wallpaperOffsetY + pan.y * 0.9f).coerceIn(-500f, 500f)
                        app.settings.update { it.copy(wallpaperScale = nextScale, wallpaperOffsetX = nextX, wallpaperOffsetY = nextY) }
                    }
                },
        ) {
            WallpaperThumb(item)
        }
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 8.dp)
                .size(width = 120.dp, height = 18.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(Color.Black.copy(alpha = 0.35f)),
        )
        Text(
            text = "Предпросмотр: ${item.title}",
            color = Fg,
            fontSize = 11.sp,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(Color.Black.copy(alpha = 0.35f))
                .padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}

@Composable
fun TriggersPane(settings: AppSettings) {
    val app = WallpaperApp.instance
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pinTest by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }

    fun upd(block: (AppSettings) -> AppSettings) {
        scope.launch { app.settings.update(block) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        TriggerRow("Плитка в шторке", "Кнопка Wallpaper в панели уведомлений", settings.tile) { upd { it.copy(tile = it.tile.not()) } }
        TriggerRow("Свайп по рабочему столу", "Горизонтальный жест на live wallpaper", settings.swipe) { upd { it.copy(swipe = it.swipe.not()) } }
        TriggerRow("Двойное касание", "Два быстрых тапа по обоям", settings.doubleTap) { upd { it.copy(doubleTap = it.doubleTap.not()) } }
        TriggerRow("Тройное касание", "Три быстрых тапа по обоям", settings.tripleTap) { upd { it.copy(tripleTap = it.tripleTap.not()) } }
        TriggerRow("Встряхивание", "Акселерометр, работает в фоне", settings.shake) { upd { it.copy(shake = it.shake.not()) } }
        TriggerRow("Громкость + затем −", "Нужна служба спец. возможностей", settings.volumeCombo) {
            upd { it.copy(volumeCombo = it.volumeCombo.not()) }
        }
        Button(
            onClick = {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            colors = ButtonDefaults.buttonColors(containerColor = Surface2, contentColor = Fg),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Открыть специальные возможности") }
        TriggerRow("Долгое нажатие на иконку", "Системный shortcut в меню иконки", settings.longPress) { upd { it.copy(longPress = it.longPress.not()) } }
        TriggerRow("Секретный код", "В калькуляторе: PIN + % переключает, PIN + = открывает сейф", settings.pinEnabled) {
            upd { it.copy(pinEnabled = it.pinEnabled.not()) }
        }
        Field("Код", settings.pin) { v -> upd { it.copy(pin = v.filter(Char::isDigit).take(8)) } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Проверить код", pinTest, Modifier.weight(1f)) { pinTest = it }
            Button(
                onClick = {
                    scope.launch {
                        if (pinTest == settings.pin) {
                            app.switcher.toggle("pin")
                            pinTest = ""
                        } else Toast.makeText(ctx, "Неверный код", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Surface2, contentColor = Fg),
            ) { Text("OK") }
        }
        TriggerRow("По расписанию", "Ночью скрытый набор, днём публичный", settings.schedule) { upd { it.copy(schedule = it.schedule.not()) } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Ночь с", settings.nightStart, Modifier.weight(1f)) { v -> upd { it.copy(nightStart = v) } }
            Field("до", settings.nightEnd, Modifier.weight(1f)) { v -> upd { it.copy(nightEnd = v) } }
        }
        TriggerRow("Наушники", "Подключение — скрытый, отключение — публичный", settings.headphones) {
            upd { it.copy(headphones = it.headphones.not()) }
        }
        TriggerRow("Определённая Wi-Fi сеть", "SSID переключает на скрытый набор", settings.wifi) { upd { it.copy(wifi = it.wifi.not()) } }
        Field("SSID", settings.wifiSsid) { v -> upd { it.copy(wifiSsid = v) } }
        TriggerRow("Голосовая команда", "Фраза включает переключение, пока экран открыт", settings.voice) {
            upd { it.copy(voice = it.voice.not()) }
        }
        Field("Фраза", settings.voicePhrase) { v -> upd { it.copy(voicePhrase = v) } }
        Button(
            onClick = {
                if (!settings.voice) {
                    Toast.makeText(ctx, "Включите голосовую команду", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                    Toast.makeText(ctx, "Распознавание речи недоступно", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
                rec.setRecognitionListener(object : RecognitionListener {
                    override fun onResults(results: android.os.Bundle) {
                        val said = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()?.lowercase(Locale.getDefault()).orEmpty()
                        val phrase = settings.voicePhrase.trim().lowercase(Locale.getDefault())
                        if (phrase.isNotBlank() && said.contains(phrase)) {
                            scope.launch { app.switcher.toggle("voice") }
                            Toast.makeText(ctx, "Услышано: $said", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(ctx, "Услышано: $said", Toast.LENGTH_SHORT).show()
                        }
                        listening = false
                        rec.destroy()
                    }
                    override fun onError(error: Int) { listening = false; rec.destroy() }
                    override fun onReadyForSpeech(params: android.os.Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: android.os.Bundle?) {}
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })
                listening = true
                rec.startListening(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    },
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = Surface2, contentColor = Fg),
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (listening) "Слушаю…" else "Сказать команду") }
    }
}

@Composable
fun StealthPane(settings: AppSettings) {
    val app = WallpaperApp.instance
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    fun upd(block: (AppSettings) -> AppSettings) {
        scope.launch { app.settings.update(block) }
    }
    val aliases = listOf(
        "tools" to "Инструменты",
        "files" to "Файлы",
        "weather" to "Погода",
        "gallery" to "Галерея",
        "settings" to "Настройки",
    )
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        CardBlock {
            SectionLabel("Нейтральное имя")
            Spacer(Modifier.height(8.dp))
            Field("Имя на рабочем столе", settings.appName) { v -> upd { it.copy(appName = v.take(24)) } }
        }
        CardBlock {
            SectionLabel("Иконка-алиас")
            Spacer(Modifier.height(8.dp))
            aliases.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    row.forEach { (id, label) ->
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, if (settings.alias == id) Accent else Border, RoundedCornerShape(8.dp))
                                .background(Surface2)
                                .clickable { upd { it.copy(alias = id) } }
                                .padding(12.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text(label, color = Fg, fontSize = 12.sp) }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
        TriggerRow("Скрыть иконку с рабочего стола", "Значок пропадает. Вход — долгое нажатие плитки «Обои» в шторке.", settings.hideIcon) {
            upd { it.copy(hideIcon = it.hideIcon.not()) }
        }
        TriggerRow("Калькулятор-обманка", "При открытии виден калькулятор. PIN + = открывает этот экран.", settings.decoy) {
            upd { it.copy(decoy = it.decoy.not()) }
        }
        Text(
            "Сейф исключён из недавних приложений. В recents остаётся только калькулятор.",
            color = Muted,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Button(
            onClick = {
                Toast.makeText(ctx, "Сейф скрыт из недавних. Закройте экран кнопкой «назад».", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Surface2, contentColor = Fg),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Как выглядит в недавних") }
    }
}

@Composable
private fun TriggerRow(title: String, hint: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceCol)
            .border(1.dp, Border, RoundedCornerShape(12.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Fg, fontSize = 14.sp)
            Spacer(Modifier.height(2.dp))
            Text(hint, color = Muted, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Bg),
        )
    }
}

@Composable
private fun Field(label: String, value: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Fg,
            unfocusedTextColor = Fg,
            focusedBorderColor = Accent,
            unfocusedBorderColor = Border,
            focusedLabelColor = Muted,
            unfocusedLabelColor = Muted,
            cursorColor = Accent,
        ),
    )
}

@Composable
private fun CardBlock(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceCol)
            .border(1.dp, Border, RoundedCornerShape(12.dp))
            .padding(14.dp),
    ) { content() }
}

@Composable
private fun ProfileChip(label: String, active: Boolean, tone: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (active) SurfaceCol else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (active) tone else Muted, fontSize = 13.sp)
    }
}

private fun kindLabel(kind: MediaKind) = when (kind) {
    MediaKind.STILL -> "Фото"
    MediaKind.GIF -> "GIF"
    MediaKind.LIVE -> "Live"
}

private fun queryName(ctx: android.content.Context, uri: Uri): String {
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) return it.getString(0) ?: "wallpaper"
    }
    return "wallpaper"
}

private fun <T> MediaMetadataRetriever.use(block: (MediaMetadataRetriever) -> T): T {
    return try { block(this) } finally { release() }
}
